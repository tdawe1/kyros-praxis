Eval definitions placeholder.

