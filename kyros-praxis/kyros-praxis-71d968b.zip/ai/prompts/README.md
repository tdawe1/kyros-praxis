Prompt store placeholder.

