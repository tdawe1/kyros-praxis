Performance tests placeholder.

