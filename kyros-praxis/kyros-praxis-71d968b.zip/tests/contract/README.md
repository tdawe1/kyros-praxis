Contract tests placeholder.

