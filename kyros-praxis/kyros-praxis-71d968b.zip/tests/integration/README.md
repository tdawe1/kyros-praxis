Integration tests placeholder.

